# SignMap Microservices Starter

This archive contains starter projects, OpenAPI specs, SQL init scripts, Dockerfiles, Helm charts, and a Postman collection for:
- Contribution Service
- Payment Service

Location: /mnt/data/signmap_starter

How to use:
- Edit connection strings in each project's appsettings.json or environment variables.
- Build with dotnet (requires .NET 8 SDK) and run.
- Apply SQL scripts to your PostgreSQL/PostGIS instance.
- Use Postman collection in `postman/SignMap.postman_collection.json`.


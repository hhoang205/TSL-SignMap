using System;
using System.Collections.Generic;
namespace PaymentService.Infrastructure.Models;
public class Payment
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public long AmountCents { get; set; }
    public string Currency { get; set; } = "USD";
    public string? Provider { get; set; }
    public string? ProviderTxId { get; set; }
    public string Status { get; set; } = "pending";
    public Dictionary<string,string> Metadata { get; set; } = new();
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}
using Microsoft.AspNetCore.Mvc;
using PaymentService.Api.DTOs;
using PaymentService.Infrastructure;
using PaymentService.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace PaymentService.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PaymentsController : ControllerBase
{
    private readonly PaymentContext _db;
    public PaymentsController(PaymentContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] Guid? userId, [FromQuery] int page = 1, [FromQuery] int size = 20)
    {
        var q = _db.Payments.AsQueryable();
        if (userId.HasValue) q = q.Where(p => p.UserId == userId.Value);
        var items = await q.OrderByDescending(p => p.CreatedAt).Skip((page-1)*size).Take(size).ToListAsync();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var item = await _db.Payments.FindAsync(id);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] PaymentCreateDto dto)
    {
        var model = new Payment
        {
            Id = Guid.NewGuid(),
            UserId = dto.UserId,
            AmountCents = dto.AmountCents,
            Currency = dto.Currency ?? "USD",
            Provider = dto.Provider,
            ProviderTxId = dto.ProviderTxId,
            Status = dto.Status ?? "pending",
            Metadata = dto.Metadata ?? new Dictionary<string,string>(),
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
        _db.Payments.Add(model);
        await _db.SaveChangesAsync();
        // TODO: emit PaymentCompleted event if status==completed
        return CreatedAtAction(nameof(Get), new { id = model.Id }, model);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(Guid id, [FromBody] PaymentUpdateDto dto)
    {
        var model = await _db.Payments.FindAsync(id);
        if (model == null) return NotFound();
        model.Status = dto.Status ?? model.Status;
        model.Metadata = dto.Metadata ?? model.Metadata;
        model.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return Ok(model);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var model = await _db.Payments.FindAsync(id);
        if (model == null) return NotFound();
        _db.Payments.Remove(model);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
using System;
using System.Collections.Generic;
namespace PaymentService.Api.DTOs;
public class PaymentUpdateDto
{
    public string? Status { get; set; }
    public Dictionary<string,string>? Metadata { get; set; }
}
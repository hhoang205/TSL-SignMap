# Payment Service

Minimal API + EF Core starter for Payment Service.
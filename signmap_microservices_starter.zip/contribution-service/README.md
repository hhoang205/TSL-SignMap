# Contribution Service

Minimal API + EF Core starter for Contribution Service.
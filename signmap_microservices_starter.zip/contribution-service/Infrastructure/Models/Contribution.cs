using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
namespace ContributionService.Infrastructure.Models;
public class Contribution
{
    public Guid Id { get; set; }
    public Guid UserId { get; set; }
    public string Type { get; set; } = "new";
    public Guid? SignId { get; set; }
    public double Lat { get; set; }
    public double Lng { get; set; }
    public string? Description { get; set; }
    public List<string> Images { get; set; } = new();
    public string Status { get; set; } = "pending";
    public string? AiInference { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
}
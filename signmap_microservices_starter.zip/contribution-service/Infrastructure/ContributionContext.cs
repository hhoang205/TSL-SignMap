using Microsoft.EntityFrameworkCore;
using ContributionService.Infrastructure.Models;
namespace ContributionService.Infrastructure;
public class ContributionContext : DbContext
{
    public ContributionContext(DbContextOptions<ContributionContext> options) : base(options) { }
    public DbSet<Contribution> Contributions { get; set; } = null!;
}
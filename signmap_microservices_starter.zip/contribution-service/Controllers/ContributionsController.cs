using Microsoft.AspNetCore.Mvc;
using ContributionService.Api.DTOs;
using ContributionService.Infrastructure;
using ContributionService.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;

namespace ContributionService.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ContributionsController : ControllerBase
{
    private readonly ContributionContext _db;
    public ContributionsController(ContributionContext db) => _db = db;

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] int page = 1, [FromQuery] int size = 20)
    {
        var items = await _db.Contributions
            .OrderByDescending(c => c.CreatedAt)
            .Skip((page-1)*size).Take(size).ToListAsync();
        return Ok(items);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id)
    {
        var item = await _db.Contributions.FindAsync(id);
        if (item == null) return NotFound();
        return Ok(item);
    }

    [HttpPost]
    public async Task<IActionResult> Post([FromBody] ContributionCreateDto dto)
    {
        var model = new Contribution
        {
            Id = Guid.NewGuid(),
            UserId = dto.UserId,
            Type = dto.Type,
            SignId = dto.SignId,
            Lat = dto.Lat,
            Lng = dto.Lng,
            Description = dto.Description,
            Images = dto.Images ?? new List<string>(),
            Status = "pending",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
        _db.Contributions.Add(model);
        await _db.SaveChangesAsync();
        // TODO: publish ContributionCreated event
        return CreatedAtAction(nameof(Get), new { id = model.Id }, model);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Put(Guid id, [FromBody] ContributionUpdateDto dto)
    {
        var model = await _db.Contributions.FindAsync(id);
        if (model == null) return NotFound();
        if (model.Status != "pending") return BadRequest(new { error = "Only pending contributions can be updated." });
        if (model.UserId != dto.UserId) return Forbid();
        model.Description = dto.Description ?? model.Description;
        model.Images = dto.Images ?? model.Images;
        model.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return Ok(model);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id, [FromQuery] Guid userId)
    {
        var model = await _db.Contributions.FindAsync(id);
        if (model == null) return NotFound();
        if (model.Status != "pending") return BadRequest(new { error = "Only pending contributions can be deleted." });
        if (model.UserId != userId) return Forbid();
        _db.Contributions.Remove(model);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
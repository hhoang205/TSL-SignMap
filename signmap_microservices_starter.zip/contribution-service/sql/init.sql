-- PostgreSQL + PostGIS example for contributions table
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE IF NOT EXISTS contributions (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  type VARCHAR(20) NOT NULL,
  sign_id UUID,
  geom geometry(Point,4326) NOT NULL,
  description TEXT,
  images JSONB DEFAULT '[]',
  status VARCHAR(20) DEFAULT 'pending',
  ai_inference JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_contrib_geom ON contributions USING GIST(geom);
CREATE INDEX IF NOT EXISTS idx_contrib_status ON contributions(status);
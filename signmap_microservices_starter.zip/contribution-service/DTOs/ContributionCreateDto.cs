using System;
using System.Collections.Generic;
namespace ContributionService.Api.DTOs;
public class ContributionCreateDto
{
    public Guid UserId { get; set; }
    public string Type { get; set; } = "new";
    public Guid? SignId { get; set; }
    public double Lat { get; set; }
    public double Lng { get; set; }
    public string? Description { get; set; }
    public List<string>? Images { get; set; }
    public string? Source { get; set; }
}